package com.nabla.springbootcallenabledapp;

import java.net.URI;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Call;
import com.twilio.type.PhoneNumber;

@SpringBootApplication
public class SpringBootCallEnabledAppApplication implements ApplicationRunner {

	        private final static String ACCOUNT_SID = "ACa75b5be3493d7d2ece9b4911cc2fd73d";
			private final static String AUTH_ID = "94e1b7e1451ecffa5114db73ab15c8e9";
			private final static String FROM_NUMBER="+17704645384";
			private final static String TO_NUMBER = "+918208230685";
	
			static {
				   Twilio.init(ACCOUNT_SID, AUTH_ID);
				}
			
	public static void main(String[] args) {
		SpringApplication.run(SpringBootCallEnabledAppApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		Call.creator(new PhoneNumber(TO_NUMBER), new PhoneNumber(FROM_NUMBER),
				   new URI("http://demo.twilio.com/docs/voice.xml")).create();
		
	}

}
