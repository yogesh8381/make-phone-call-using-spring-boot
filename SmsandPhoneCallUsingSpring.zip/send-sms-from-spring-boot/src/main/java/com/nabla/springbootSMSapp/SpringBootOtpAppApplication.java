package com.nabla.springbootSMSapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOtpAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOtpAppApplication.class, args);
	}

}
